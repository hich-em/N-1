<?php

return array(
	'charcoal' => array(
		'image' => 'charcoal',
	),

	'pink' => array(
		'image' => 'pink',
	),

	'orange' => array(
		'image' => 'orange',
	),

	'green' => array(
		'image' => 'green',
	),

	'blue' => array(
		'image' => 'blue',
	),

	'purple' => array(
		'image' => 'purple',
	),

	'turquoise' => array(
		'image' => 'turquoise',
	),

	'slate' => array(
		'image' => 'slate',
	),

	'black' => array(
		'image' => 'black',
	),
);
